// Form validate
function validate(form) {
    var name = form.n.value;
    var kana = form.k.value;
    var mail = form.m.value;
    if (name == "" || kana == "" || mail == "") {
        return false;
    }

    return true;
}
