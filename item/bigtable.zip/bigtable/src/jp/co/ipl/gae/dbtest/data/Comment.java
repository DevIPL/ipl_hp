package jp.co.ipl.gae.dbtest.data;

import javax.jdo.PersistenceManager;
import javax.jdo.annotations.IdGeneratorStrategy;
import javax.jdo.annotations.IdentityType;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;

import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;

import jp.co.ipl.gae.dbtest.util.PMF;



/**
 * �R�����g
 * @author iwai
 *
 */
@PersistenceCapable(identityType = IdentityType.APPLICATION)
public class Comment {
	@PrimaryKey
	@Persistent(valueStrategy = IdGeneratorStrategy.IDENTITY)
	private Key id;
	PersistenceManager pm = PMF.get().getPersistenceManager();

	@Persistent
	private String text;

	public Comment(String text) {
		this.text = text;
	}


	/**
	 * @return the id
	 */
	public Key getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Key id) {
		this.id = id;
	}

	/**
	 * @return the text
	 */
	public String getText() {
		return text;
	}

	/**
	 * @param text the text to set
	 */
	public void setText(String text) {
		this.text = text;
	}

	public String getKeyStr() {
		return KeyFactory.keyToString(id);
	}
	
	
}
