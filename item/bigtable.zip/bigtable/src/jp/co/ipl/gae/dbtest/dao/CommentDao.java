package jp.co.ipl.gae.dbtest.dao;

import javax.jdo.PersistenceManager;

import jp.co.ipl.gae.dbtest.data.Comment;


public class CommentDao {
	public void insert(PersistenceManager pm, Comment info) {
		pm.makePersistent(info);
	}
	public void update(PersistenceManager pm, Comment info) {
		insert(pm, info);
	}
	public void delete(PersistenceManager pm, Comment info) {
		pm.deletePersistent(info);
	}
	public Comment selectKey(PersistenceManager pm, Long id) {
		return pm.getObjectById(Comment.class, id);
	}
}
