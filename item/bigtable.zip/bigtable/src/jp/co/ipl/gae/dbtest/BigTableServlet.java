package jp.co.ipl.gae.dbtest;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.ipl.gae.dbtest.dao.ArticleDao;
import jp.co.ipl.gae.dbtest.dao.CommentDao;
import jp.co.ipl.gae.dbtest.data.Article;
import jp.co.ipl.gae.dbtest.data.Comment;
import jp.co.ipl.gae.dbtest.util.PMF;

import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;

@SuppressWarnings("serial")
public class BigTableServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		resp.setContentType("text/plain");
		resp.setCharacterEncoding("utf-8");
		String action = (String)req.getParameter("action");
		String id = (String)req.getParameter("id");
		
		if(action == null||id == null) {
			resp.getWriter().print("�p�����[�^���ُ�ł��B");
			return;
		}
		
		if(action.equals("deletecomment")) {
			deleteComment(KeyFactory.stringToKey(id));
		}
		if(action.equals("delete")) {
			delete(KeyFactory.stringToKey(id));
		}
		resp.sendRedirect("/");
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/plain");
		resp.setCharacterEncoding("utf-8");

		String action = (String)req.getParameter("action");
		String id = (String)req.getParameter("id");
		String text = (String)req.getParameter("text");

		if(action == null) {
			resp.getWriter().print("�p�����[�^���ُ�ł��B");
			return;
		}
		if(action.equals("insert")) {
			insert(text);
		}
		if(action.equals("edit")) {
			if(id == null) {
				resp.getWriter().print("�p�����[�^���ُ�ł��B");
				return;
			}
			update(text, KeyFactory.stringToKey(id));
		}

		if(action.equals("addcomment")) {
			if(id == null) {
				resp.getWriter().print("�p�����[�^���ُ�ł��B");
				return;
			}
			addComment(text, KeyFactory.stringToKey(id));
		}
		resp.sendRedirect("/");
	}	
	
	private void insert(String text) {
		ArticleDao dao = new ArticleDao();
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Article info = new Article(text, new Date());
		dao.insert(pm, info);
		pm.close();
	}
	
	private void update(String text, Key id) {
		ArticleDao dao = new ArticleDao();
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Article info = (Article)pm.getObjectById(Article.class,id);
		info.setText(text);
		dao.update(pm, info);
		pm.close();
		
	}
	private void delete(Key id) {
		ArticleDao dao = new ArticleDao();
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Article info = (Article)pm.getObjectById(Article.class,id);
		if(info == null) {
			return;
		}
		dao.delete(pm, info);
		pm.close();
	}
	
	private void addComment(String text, Key articleId) {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Article article = (Article)pm.getObjectById(Article.class,articleId);
		
		List<Comment> comments = article.getComments();
		Comment info = new Comment(text);
		comments.add(info);
		pm.close();
	}
	
	
	private void deleteComment(Key id) {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		Comment info = (Comment)pm.getObjectById(Comment.class,id);
		CommentDao dao = new CommentDao();
		dao.delete(pm, info);
		pm.close();
	}
}
