package jp.co.ipl.gae.dbtest.data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.annotations.IdGeneratorStrategy;
import javax.jdo.annotations.IdentityType;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;

import jp.co.ipl.gae.dbtest.util.PMF;

import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;


/**
 * �L��
 * @author iwai
 *
 */
@PersistenceCapable(identityType = IdentityType.APPLICATION)
public class Article {
	@PrimaryKey
	@Persistent(valueStrategy = IdGeneratorStrategy.IDENTITY)
	private Key id;

	PersistenceManager pm = PMF.get().getPersistenceManager();

	List<Comment> comments = new ArrayList<Comment>();
	
	public String getKeyStr() {
		return KeyFactory.keyToString(id);
	}
	
	/**
	 * @return the options
	 */
	public List<Comment> getComments() {
		return comments;
	}

	/**
	 * @param comments the options to set
	 */
	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}

	@Persistent
	private String text;

	@Persistent
	private Date date;
	
	

	public Article(String text, Date date) {
		this.text = text;
		this.date = date;
	}

	/**
	 * @return the text
	 */
	public String getText() {
		return text;
	}

	/**
	 * @param text
	 *            the text to set
	 */
	public void setText(String text) {
		this.text = text;
	}

	/**
	 * @return the date
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * @param date
	 *            the date to set
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * @return the id
	 */
	public Key getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Key id) {
		this.id = id;
	}

}
