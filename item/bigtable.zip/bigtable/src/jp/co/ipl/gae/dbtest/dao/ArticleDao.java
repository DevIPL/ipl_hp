package jp.co.ipl.gae.dbtest.dao;

import javax.jdo.PersistenceManager;

import jp.co.ipl.gae.dbtest.data.Article;

import com.google.appengine.api.datastore.Key;


public class ArticleDao {
	public void insert(PersistenceManager pm, Article info) {
		pm.makePersistent(info);
	}
	public void update(PersistenceManager pm, Article info) {
		insert(pm, info);
	}
	public void delete(PersistenceManager pm, Article info) {
		pm.deletePersistent(info);
	}
	public Article selectKey(PersistenceManager pm, Key id) {
		return pm.getObjectById(Article.class, id);
	}
}
